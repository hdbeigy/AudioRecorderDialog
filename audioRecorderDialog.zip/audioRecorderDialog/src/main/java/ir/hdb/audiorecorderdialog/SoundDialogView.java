package ir.hdb.audiorecorderdialog;

/**
 * Created by Alhazmy13 on 12/24/15.
 */
interface SoundDialogView {

    void updateTimer(String value);

    void stopRecording();
}
