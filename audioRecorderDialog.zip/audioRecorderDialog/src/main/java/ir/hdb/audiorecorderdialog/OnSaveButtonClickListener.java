package ir.hdb.audiorecorderdialog;

/**
 * Created by Alhazmy13 on 12/24/15.
 */
public interface OnSaveButtonClickListener {
    void onSucceed(String path);
    void onFailure();
}
