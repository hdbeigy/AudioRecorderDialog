package ir.hdb.audiorecorderdialog

import ir.hdb.audiorecorderdialog.MediaRecorderDialog
import ir.hdb.audiorecorderdialog.OnSaveButtonClickListener

internal object AppConstants {
    var title = ""
    var message = ""
    var outPutFormat: MediaRecorderDialog.OutputFormat? = null
    var audioEncoder: MediaRecorderDialog.AudioEncoder? = null
    var onSaveButtonClickListener: OnSaveButtonClickListener? = null
    var length = -1
}