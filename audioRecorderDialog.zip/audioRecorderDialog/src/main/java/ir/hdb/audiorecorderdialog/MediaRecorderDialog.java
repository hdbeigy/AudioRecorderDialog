package ir.hdb.audiorecorderdialog;

import android.Manifest;
import android.content.Context;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;

import java.util.List;

//import net.alhazmy13.gota.Gota;
//import net.alhazmy13.gota.GotaResponse;

/**
 * Created by Alhazmy13 on 12/23/15.
 */
public class MediaRecorderDialog {

    public MediaRecorderDialog() {
    }

    public static class Builder {
        private Context context;

        public Builder(Context context) {
            this.context = context;
            AppConstants.title = "";
            AppConstants.message = "";
            AppConstants.outPutFormat = OutputFormat.MPEG_4;
            AppConstants.audioEncoder = AudioEncoder.AAC;
        }

        public MediaRecorderDialog.Builder setTitle(String title) {
            AppConstants.title = title;
            return this;
        }

        public MediaRecorderDialog.Builder setMessage(String msg) {
            AppConstants.message = msg;
            return this;
        }

        public MediaRecorderDialog.Builder show() {
//            new SoundDialog(GenralAtteribute.context).show();
//            new Gota(GenralAtteribute.context).checkPermission(new String[]{Manifest.permission.RECORD_AUDIO
//                    ,Manifest.permission.}, new Gota.OnRequestPermissionsBack() {
//                @Override
//                public void onRequestBack(GotaResponse goaResponse) {
//
//                }
//            });
//            Dexter.withContext(GenralAtteribute.context)
//                    .withPermissions(Manifest.permission.WRITE_EXTERNAL_STORAGE)
//                    .withListener(new PermissionListener() {
//                        @Override public void onPermissionGranted(PermissionGrantedResponse response) {
//                            new SoundDialog(GenralAtteribute.context).show();
//                        }
//                        @Override public void onPermissionDenied(PermissionDeniedResponse response) {/* ... */}
//                        @Override public void onPermissionRationaleShouldBeShown(PermissionRequest permission, PermissionToken token) {/* ... */}
//                    }).check();

            Dexter.withContext(context)
                    .withPermissions(
                            Manifest.permission.WRITE_EXTERNAL_STORAGE,
                            Manifest.permission.RECORD_AUDIO
                    ).withListener(new MultiplePermissionsListener() {

                @Override
                public void onPermissionsChecked(MultiplePermissionsReport report) {
                    new AudioRecorderDialog(context).show();
                }

                @Override
                public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {}
            }).check();
            return this;
        }

        public MediaRecorderDialog.Builder setOutputFormat(OutputFormat outputFormat) {
            AppConstants.outPutFormat = outputFormat;
            return this;
        }

        public MediaRecorderDialog.Builder setAudioEncoder(AudioEncoder audioEncoder) {
            AppConstants.audioEncoder = audioEncoder;
            return this;
        }

        public MediaRecorderDialog.Builder setOnSaveButtonClickListener(OnSaveButtonClickListener onSaveButtonClickListener) {
            AppConstants.onSaveButtonClickListener = onSaveButtonClickListener;
            return this;
        }

        public MediaRecorderDialog.Builder setMaxLength(TimeUnit timeUnit, int length) {
            AppConstants.length = length * timeUnit.getValue();
            return this;
        }

    }

    public enum OutputFormat {
        AAC_ADTS(6), AMR_NB(3), AMR_WB(4), DEFAULT(0), MPEG_4(2);
        private final int value;

        OutputFormat(int value) {

            this.value = value;
        }

        public int getValue() {
            return value;
        }

    }

    public enum AudioEncoder {
        AAC(3), AAC_ELD(5), AMR_NB(1), AMR_WB(2), DEFAULT(0), HE_AAC(4), VORBIS(6);

        private final int value;

        AudioEncoder(int value) {

            this.value = value;
        }

        public int getValue() {
            return value;
        }
    }

    public enum TimeUnit {
        MINUTES(60), SECONDS(1);

        private final int value;

        TimeUnit(int value) {

            this.value = value;
        }

        public int getValue() {
            return value;
        }
    }


}
